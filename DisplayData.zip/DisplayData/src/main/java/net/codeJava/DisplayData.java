package net.codeJava;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DisplayData {

	public static void main(String[] args) {
		String jdbcURL="jdbc:postgresql://localhost:2284/postgres";
		String username="operator";
		String password="CastAIP";
		
		
		try {
			Connection connection= DriverManager.getConnection(jdbcURL,username,password);
			System.out.println("Connected to PostgreSQL server");
			
			
			String sql = "select * from cdt_objects";
			
			Statement statement = connection.createStatement();
		
			statement.execute ( "set search_path='travel_01_local'");
			
			ResultSet result = statement.executeQuery(sql);
			
			while (result.next()) {
				int objid=result.getInt("object_id");
				String objname=result.getString("object_name");
			    String objfullname=result.getString("object_fullname");
			    String objtypestr=result.getString("object_type_str");
			    String objmangling=result.getString("object_mangling");
			    String objtypeext=result.getString("object_type_ext");
			    String objlanguagename=result.getString("object_language_name");
			    
			    System.out.printf("%d - %s - %s - %s - %s - %s - %s\n", objid,objname,objfullname,objtypestr,objmangling,objtypeext,objlanguagename);
				}
			
			  connection.close();
		}
		catch(SQLException e) {
			System.out.println("Error in connecting to PostgreSQL server");
			e.printStackTrace();
		}
	}
}
